package com.project.booklnb.model;

import java.util.Arrays;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Member {
	@Id
	private String email;
	private String name;
	private String password;
	private String securityQuestion;
	private String securityAnswer;
	private String residentialAddress;
	private String booksBorrowed[];
	private String booksLent[];
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public String getResidentialAddress() {
		return residentialAddress;
	}
	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}
	public String[] getBooksBorrowed() {
		return booksBorrowed;
	}
	public void setBooksBorrowed(String[] booksBorrowed) {
		this.booksBorrowed = booksBorrowed;
	}
	public String[] getBooksLent() {
		return booksLent;
	}
	public void setBooksLent(String[] booksLent) {
		this.booksLent = booksLent;
	}
	public Member(String email, String name, String password, String securityQuestion, String securityAnswer,
			String residentialAddress, String[] booksBorrowed, String[] booksLent) {
		super();
		this.email = email;
		this.name = name;
		this.password = password;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.residentialAddress = residentialAddress;
		this.booksBorrowed = booksBorrowed;
		this.booksLent = booksLent;
	}
	
	public Member() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Member [email=" + email + ", name=" + name + ", password=" + password + ", securityQuestion="
				+ securityQuestion + ", securityAnswer=" + securityAnswer + ", residentialAddress=" + residentialAddress
				+ ", booksBorrowed=" + Arrays.toString(booksBorrowed) + ", booksLent=" + Arrays.toString(booksLent)
				+ "]";
	}
	
	
}

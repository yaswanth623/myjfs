import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Member } from 'src/app/member.model';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private membserv:MemberService,private router:Router) { }

  member:Member={"email":"","name":"","password":"","securityQuestion":"","securityAnswer":"","residentialAddress":"","booksBorrowed":[],"booksLent":[]};
  ngOnInit(): void {
  }

  email:string;
  password:string;

  loginValidate(){
    if(this.email == 'admin@booklnb.com' && this.password == 'password'){
      localStorage.setItem("email",this.email);
          localStorage.setItem("login","true");
          this.router.navigate(['admin']);
    }else{
    this.membserv.getMember(this.email).subscribe(
      data=>{this.member=data;
        const emailCheck = /.com/;
        if ( this.email.search(emailCheck) == -1) {
            alert('Invalid Email Address');
        }
        else if(this.email == null || this.password == null){
          alert('Please enter both Email Address and Password')
        }
        else if(this.member == null){
          alert('Email Address does not exist');
        }else if(!(this.member.password == this.password)){
          alert('Password is incorrect');
        }else{
          localStorage.setItem("email",this.email);
          localStorage.setItem("login","true");
          this.router.navigate(['homefeed']);
        }
      },
      error=>console.log(error)
    )}
  }

  crEmail:string;
  crName:string;
  crPassword:string;
  crConfirmPassword:string;
  crSecurityQuestion:string;
  crSecurityAnswer:string;
  crResidentialAddress:string;
  crBooksBorrowed:string[]=null;
  crBooksLent:string[]=null;

  crMember:Member;
  
  signup(){
    this.membserv.getMember(this.crEmail).subscribe(
      data=>{this.member=data;
    
    if(!(this.member == null)){
      alert('Email address already exists')
    }else{
    this.crMember={"email":this.crEmail,"name":this.crName,"password":this.crConfirmPassword,"securityQuestion":this.crSecurityQuestion,"securityAnswer":this.crSecurityAnswer,"residentialAddress":this.crResidentialAddress,"booksBorrowed":this.crBooksBorrowed,"booksLent":this.crBooksLent};
    if(this.crName == null || this.crPassword== null || this.crConfirmPassword== null || this.crSecurityQuestion== null || this.crSecurityAnswer== null || this.crResidentialAddress== null){
      alert('Please provide all details');
    }else if(this.crEmail.search('@') < 1){
      alert('Invalid Email Address');
    }else if(this.crResidentialAddress.length < 15){
      alert('Residential Address is too short.');
    }else if(this.crPassword.length < 6){
      alert('Password must be atleast 6 characters long')
    }else if(this.crPassword != this.crConfirmPassword){
      alert ('Passwords mismatch');
    }else{
          this.membserv.createMember(this.crMember).subscribe(
            data=>console.log(data),
            error=>console.log(error)
          );
          this.router.navigate(['']);
          alert('Congrats!!! You are now a member of the BookLnB family. \nLogin to the portal to borrow or lend books.');
          location.reload();
      }
  }
})
}
}

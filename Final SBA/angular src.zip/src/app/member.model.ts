export class Member{
    email:string;
	name:string;
	password:string;
	securityQuestion:string;
	securityAnswer:string;
	residentialAddress:string;
	booksBorrowed:string[];
	booksLent:string[];
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Member } from 'src/app/member.model';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-my-info',
  templateUrl: './my-info.component.html',
  styleUrls: ['./my-info.component.css']
})
export class MyInfoComponent implements OnInit {

  constructor(private router:Router,private daosrv:MemberService) { }
  email:string = localStorage.getItem('email');
  member:Member;

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }else{
      this.daosrv.getMember(this.email).subscribe(
        data=>this.member=data,
        error=>console.log(error)
      )
    }
  }

  logout(){
    localStorage.setItem("login","");
    location.reload();
  }

}

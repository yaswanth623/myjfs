package com.project.booklnb.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.project.booklnb.model.Member;

@Component
public class MemberDao {
	@Autowired
	MongoTemplate mongoTemplate;
	
	public Member saveMember(Member member) {
		try {
			mongoTemplate.save(member);
			return member;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Object getMemberByEmail(String email) {
		try {
			Query query = new Query();
			email=email+".com";
			query.addCriteria(Criteria.where("email").is(email));
			Member mem= mongoTemplate.findOne(query,Member.class);
			if(mem!=null){
				return mem;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	public String updatePassword(String email, String newPassword){
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(email));
			Update update=new Update();
			update.set("password", newPassword);
			mongoTemplate.updateFirst(query, update, Member.class);
			return "SucessFully updated";
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "unable to update";
	}
	
	public ArrayList<String> displayLentByOthers(String email) {
		try {
			List<Member> allMembers=mongoTemplate.findAll(Member.class);
			ArrayList<String> theNewList=new ArrayList<String>();
			for (int i = 0; i < allMembers.size(); i++) {
				  if(allMembers.get(i).getBooksLent() == null) { continue; }
				  String eml=email+".com";
				  if(allMembers.get(i).getEmail().equals(eml)) {continue;}
				  //System.out.println(allMembers.get(i).getEmail());
				  String[] theList = allMembers.get(i).getBooksLent();
				  for(int j = 0; j < theList.length; j++) {
					  theNewList.add(theList[j]+":"+allMembers.get(i).getName());
				  }				  
			}
			return theNewList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public List<Member> allMembers(){
		try {
			List<Member> allMembers=mongoTemplate.findAll(Member.class);
			return allMembers;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String addToBorrowedByUser(String newBook,String email){
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(email));
			Member member= mongoTemplate.findOne(query, Member.class);
			System.out.println(member);
			if(member!=null) {
				Update update=new Update();
				update.push("booksBorrowed",newBook);
				mongoTemplate.updateFirst(query,update,Member.class);
				return "Added Sucessfully";
			}else{
				return "Member not found";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	public String removeFromOriginalList(String newBook,String lenderName){
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(lenderName));
			Member member= mongoTemplate.findOne(query, Member.class);
			System.out.println(member);
			if(member!=null) {
				Update update=new Update();
				update.pull("booksLent",newBook);
				mongoTemplate.updateFirst(query,update,Member.class);
				return "Removed Sucessfully";
			}else{
				return "Member not found";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	public String addBookToBookLent(String email, String title,String author,String format,String condition) {
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(email));
			Member member= mongoTemplate.findOne(query, Member.class);
			System.out.println(member);
			String book=title+":"+author+":"+format+":"+condition;
			if(member!=null) {
				Update update=new Update();
				update.push("booksLent",book);
				mongoTemplate.updateFirst(query,update,Member.class);
				return "Books are added any one can See";
				}else{
					return "not added";
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		return "unable to add";
	}
	
	public String returnBook(String email,String book) {
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(email));
			Member member= mongoTemplate.findOne(query, Member.class);
			if(member!=null) {
				Update update=new Update();
				update.pull("booksBorrowed",book);
				mongoTemplate.updateFirst(query,update,Member.class);
				return "SucessFully Returned";
				}else{
					return "error";
					}
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
		   return "not Removed";
	   }
	

	public ArrayList<String> borrowedByMe(String email) {
		try {
			Query query = new Query();
			email=email+".com";
			query.addCriteria(Criteria.where("email").is(email));
			Member mem= mongoTemplate.findOne(query,Member.class);
			ArrayList<String> theNewList=new ArrayList<String>();
			String[] theList =mem.getBooksBorrowed();
			if (theList.length == 0) {
				return null;
			} else {
				for (int i = 0; i < theList.length; i++) {
					theNewList.add(theList[i]);
				}
				return theNewList;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<String> lentByMe(String email) {
		try {
			Query query = new Query();
			email=email+".com";
			query.addCriteria(Criteria.where("email").is(email));
			Member mem= mongoTemplate.findOne(query,Member.class);
			ArrayList<String> theNewList=new ArrayList<String>();
			String[] theList =mem.getBooksLent();
			if (theList.length == 0) {
				return null;
			} else {
				for (int i = 0; i < theList.length; i++) {
					theNewList.add(theList[i]);
				}
				return theNewList;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}

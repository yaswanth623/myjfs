import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private membserv:MemberService,private router:Router) { }

  ngOnInit(): void {
  }

  email:string = localStorage.getItem("email");
  newPassword:string;
  confirmNewPassword:string;

  changePass(){
    if(this.newPassword == null || this.confirmNewPassword == null){
      alert('Please fill both the password fields');
    }else if(this.newPassword.length < 6 || this.confirmNewPassword.length < 6){
      alert('Password must be atleast 6 characters long')
    }else if(!(this.newPassword === this.confirmNewPassword)){
      alert('Passwords Mismatch')
    }else{
       this.membserv.changePassword(this.email,this.confirmNewPassword).subscribe(
        error=>console.log(error)
       );
      alert('Password changed successfully\nYou can now login with your new password')
      this.router.navigate(['login']);
    }
  }

}

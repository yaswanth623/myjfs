import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './Components/admin/admin.component';
import { AddbooksComponent } from './Components/addbooks/addbooks.component';
import { BorrowedbooksComponent } from './Components/borrowedbooks/borrowedbooks.component';
import { ChangePasswordComponent } from './Components/change-password/change-password.component';
import { ErrorComponent } from './Components/error/error.component';
import { ForgotPasswordComponent } from './Components/forgot-password/forgot-password.component';
import { HomeFeedComponent } from './Components/home-feed/home-feed.component';
import { LentbymeComponent } from './Components/lentbyme/lentbyme.component';
import { LoginComponent } from './Components/login/login.component';
import { MyInfoComponent } from './Components/my-info/my-info.component';
import { AllUsersComponent } from './Components/all-users/all-users.component';


const routes: Routes = [
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'homefeed',component:HomeFeedComponent},
  {path:'homefeed/lend',component:AddbooksComponent},
  {path:'homefeed/borrowed',component:BorrowedbooksComponent},
  {path:'homefeed/lent',component:LentbymeComponent},
  {path:'homefeed/myinfo',component:MyInfoComponent},
  {path:'login/forgotpassword',component:ForgotPasswordComponent},
  {path:'login/forgotpassword/changepassword',component:ChangePasswordComponent},
  {path:'admin',component:AdminComponent},
  {path:'admin/allusers',component:AllUsersComponent},
  {path:'**',component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

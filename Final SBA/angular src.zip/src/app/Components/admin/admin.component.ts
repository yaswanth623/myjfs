import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private daosrv:MemberService, private router:Router) { }

  email:string = localStorage.getItem('email');
  theList:any[];

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }else{
      this.daosrv.displayLentByOthers(this.email).subscribe(
        data=>this.theList=data,
        error=>console.log(error)
      )
    }
  }

  bk:string[];
  bk1:string;
  a:boolean;
  removeBook(book){
    this.a=confirm('The book will be removed from the database\nClick OK to confirm')
    if(this.a == true){
      this.bk=book.split(":");
      this.bk1=this.bk[0]+":"+this.bk[1]+":"+this.bk[2]+":"+this.bk[3]
      this.daosrv.removeBorrowBook(this.bk[4],this.bk1).subscribe(data=>console.log(data),error=>console.log(error))
      location.reload();
    }
  }

  logout(){
    localStorage.setItem("login","");
    location.reload();
  }


}

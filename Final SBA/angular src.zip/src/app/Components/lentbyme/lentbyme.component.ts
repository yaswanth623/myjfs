import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-lentbyme',
  templateUrl: './lentbyme.component.html',
  styleUrls: ['./lentbyme.component.css']
})
export class LentbymeComponent implements OnInit {

  constructor(private daosrv:MemberService,private router:Router) { }
  email:string = localStorage.getItem('email');
  theList:any[];

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }else{
    this.daosrv.lentByMe(this.email).subscribe(
      data=>this.theList=data,
      error=>console.log(error)
    )}
  }

  logout(){
    localStorage.setItem("login","");
    location.reload();
  }
}

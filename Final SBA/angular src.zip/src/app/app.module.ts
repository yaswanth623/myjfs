import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { HomeFeedComponent } from './Components/home-feed/home-feed.component';
import { TitlePipe } from './Components/title.pipe';
import { AuthorPipe } from './Components/author.pipe';
import { MemberNamePipe } from './Components/member-name.pipe';
import { LoginComponent } from './Components/login/login.component';
import { FormatPipe } from './Components/format.pipe';
import { ConditionPipe } from './Components/condition.pipe';
import { AddbooksComponent } from './Components/addbooks/addbooks.component';
import { BorrowedbooksComponent } from './Components/borrowedbooks/borrowedbooks.component';
import { LentbymeComponent } from './Components/lentbyme/lentbyme.component';
import { ForgotPasswordComponent } from './Components/forgot-password/forgot-password.component';
import { MyInfoComponent } from './Components/my-info/my-info.component';
import { ChangePasswordComponent } from './Components/change-password/change-password.component';
import { ErrorComponent } from './Components/error/error.component';
import { AdminComponent } from './Components/admin/admin.component';
import { AllUsersComponent } from './Components/all-users/all-users.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeFeedComponent,
    TitlePipe,
    AuthorPipe,
    FormatPipe,
    ConditionPipe,
    MemberNamePipe,
    AddbooksComponent,
    BorrowedbooksComponent,
    LentbymeComponent,
    ForgotPasswordComponent,
    MyInfoComponent,
    ChangePasswordComponent,
    ErrorComponent,
    AdminComponent,
    AllUsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

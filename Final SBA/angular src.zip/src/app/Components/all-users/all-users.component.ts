import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Member } from 'src/app/member.model';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {

  constructor(private daosrv:MemberService, private router:Router) { }

  members:Member[]=[]

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }else{
      this.daosrv.allMembers().subscribe(
        data=>this.members=data,
        error=>console.log(error)
      )
    }
  }


  logout(){
    localStorage.setItem("login","");
    location.reload();
  }

}

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'titlesplit'
})
export class TitlePipe implements PipeTransform {

    str:string;
    str1:string[];
    transform(value: string) {
        this.str=value;
        this.str1=this.str.split(":");
        return this.str1[0];
    }

}